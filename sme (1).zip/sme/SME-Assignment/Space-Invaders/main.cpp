#include "header/Main/GameService.h"
#include <SFML/Graphics.hpp>
#include <memory> // Include for smart pointers

int main()
{
    using namespace Main;

    // Use smart pointers instead of raw pointers to manage memory
    std::unique_ptr<GameService> game_service(new GameService());
    game_service->ignite();

    while (game_service->isRunning())
    {
        game_service->update();
        game_service->render();
    }

    return 0;
}
