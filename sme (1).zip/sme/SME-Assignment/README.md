# SME-Assignment
Task 1: Setting Up Environment

I successfully configured Visual Studio Community 2022 along with the SFML Headers and libraries as per the provided instructions. This involved extracting the header and lib folders from the SFML zip file and placing them into a designated SFML folder. Subsequently, I launched the .sln file in Visual Studio, following which I encountered two deliberate errors as expected during the setup process.

This task was completed within approximately 20 minutes.

Task 2: Troubleshooting Errors

The errors were identified within the PlayerController.h file, manifesting as:
a) A syntax error indicating a missing ';' before '*'.
b) Unexpected token(s) preceding ';'.

Despite thorough examination, pinpointing the exact cause proved elusive initially. While the PlayerController.h file appeared to be error-free upon inspection, suspicions were directed towards potential issues within the included headers (PlayerView.h and PlayerModel.h).

The compiler's difficulty in recognizing PlayerView and PlayerModel as valid types at pointer declaration hinted at potential issues with their definitions. However, subsequent checks revealed that the classes were properly defined within the source/Player directory.

I meticulously verified the Header guards to prevent multiple inclusions, scrutinized the include paths, and ensured absence of Namespace Conflicts.

This task consumed approximately 2.5 hours of investigation before proceeding to the next task.

Task 3: Implementing Player Ship Firing Mechanism

Within PlayerController.cpp, I located the processPlayerInput() function where the firing implementation was intended. By uncommenting the relevant section, I initiated the implementation of the processBulletFire() function.

Task 4:In the Main function we can Use smart pointers instead of raw pointers to manage memory


# File Uploads:
- Since i am unable to compress file to 25 mb ,so I have deleted the sfml include and lib folder from the zip file and uploaded the zip file.


Thank you for your time and consideration. I look forward to your feedback and further instructions.